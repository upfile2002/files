<?php
include 'set.php';
include 'func.php';
if(isset($_GET['name'])){
$name=$_GET['name'];
$ex=explode('.',$name);
$id=$ex[2];
$server=$ex[1];
if($server=='zingmp3'){
$json=zingmp3getinfo($id);
}elseif($server=='nhaccuatui'){
$json=nctgetinfo($id);
}else{
header('location: /');
exit;
}
if(isset($id)){
$data=json_decode($json,true);
$name=$data[name];
if($name){
$casi=$data[casi];
$img='/resize.php?url='.$data[img].'&w=308&h=240';
$linkplay=$data[linkplay];
foreach([320,128,32] as $kbps){
$download.='<a style="color:#fff" rel="nofollow" href="'.$data[link][$kbps].'" class="download" title="Tải bài hát '.$name.' - '.$casi.'">Tải về chất lượng '.$kbps.'kbps</a>';
}
$lyric=$data[lyric];
$title=$name.' - '.$casi;
include 'head.php';
if($lyric){
$hlyric='<div class="top-menu"><div class="top-menu-item-first"><h2>Lời Bài Bát</h2></div><div class="top-menu-item"><span class="read-more-content"><div class="bh-lyric" id="bh-lyric">'.$lyric.'</div><div class="more"><button><a class="lr" onclick="return false;" href="#">Xem đầy đủ</a></button></div></span></div></div>';
}

echo ' <link rel="stylesheet" href="//zingmp3.tk/static/css/index.css" type="text/css"><div class="detail"><ul class="more"><li><h1>Tải Bài Hát '.$name.'</h1></li><li style="font-style: italic; font-size: 12px;">Ca sĩ: '.$casi.'</li></ul></div>



 <div class="hide-html5">
                                <audio id="audio" controls="" autoplay="" preload="auto">
                                    <source src="//mp3-320s1-zmp3.zadn.vn/22a98b92aed5478b1ec4/4747968672200872159?authen=exp=1571356675~acl=/22a98b92aed5478b1ec4/*~hmac=3ff9f40bdf01c93882d5a530aed7c683&filename=Em-Gi-Oi-Jack-K-ICM.mp3" type="audio/mpeg">
                                    <div class="menu">Trình duyệt của bạn không hỗ trợ HTML5</div>
                                </audio>
                            </div>
                            <div id="play" class="pause control"></div><div id="progress"><div id="progress_box"><div id="load_progress" style="width: 100%;"><div class="hand-control" id="hand_progress" style="left: 182.199px;"></div><div id="play_progress" style="width: 189.199px;"></div></div></div></div><div id="play_time"><span id="current_time_display">00:00 / 00:00</span></div><div id="speaker"></div><div class="volume"><span class="volumebar"><div class="volumehandle"></div></span></div>
                            <div class="quality" data-id="wbux"></div>



<p>'.$download.'</p>'.$hlyric.'<div class="title_menu"><h2>Có thể bạn quan tâm</h2></div>';
$json=$data[recommend];
for($i=0;$i<10;$i++){
$data=$json[$i];
$name=$data[name];
$casi=$data[casi];
$path=$data[path];
echo '<div class="detail"><ul class="more"><li><b><a title="Tải bài hát '.$name.'" href="/bai-hat/'.$path.'">'.$name.'</a></b></li><li style="font-style: italic"><small>Ca sĩ: '.$casi.'</small></li></ul></div>';
}
include 'end.php';
}else{
$load='home';
}}else{
$load='home';
}}else{
$load='home';
}
if($load=='home'){
header('location: /');
}
?>