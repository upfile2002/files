<?php
include 'set.php';
include 'func.php';
$title='Tải Nhạc MP3 Miễn Phí, Tải Nhạc Online Cực Nhanh, Nhạc Hay';
include 'head.php';
$titmenu=['bxhzingmp3'=>'Bảng xếp hạng âm nhạc Việt Nam','bxhnct'=>'Tải nhạc mp3 HOT nhất'];
foreach(["bxhzingmp3"=>'5',"bxhnct"=>'10'] as $func=>$max){
echo '<div class="title_menu"><div class="top-menu-item-first"><h2>'.$titmenu[$func].'</h2></div></div>';
$json=json_decode($func(),true);
for($i=0;$i<$max;$i++){
$data=$json[$i];
$name=$data[name];
$casi=$data[casi];
$titurl=$data[titurl];
echo '<div class="detail"><ul class="more"><li><b><a title="Tải bài hát '.$name.'" href="/bai-hat/'.$titurl.'"> Bài Hát '.$name.'</a></b></li><li style="font-style: italic"><small>Ca sĩ: '.$casi.'</small></li></ul></div>';
}}
include 'end.php';
?>