<?php

download('');

function download($link) {
		if (!preg_match('@/video(?:embed)?/(\d+)@i', $link, $xid)) 

		$this->xid = $xid[1];
		$this->link = 'https://ok.ru/video/' . $this->xid;

		$page = $this->GetPage($this->link);
		is_present($page, "Video has not been found", 'Video not found or it was deleted.');

		$json = cut_str($page, 'data-options="', '"');
		if (empty($json)) 
		$json = $this->json2array(html_entity_decode(str_replace('\\\\u0026', '&amp;', $json), ENT_QUOTES, 'UTF-8'), 'Error Parsing Video Data.');
		if (!empty($json['flashvars']['metadata']) && !is_array($json['flashvars']['metadata'])) $json['flashvars']['metadata'] = $this->json2array($json['flashvars']['metadata'], 'Error Parsing Video Metadata.');
		else if (empty($json['flashvars']['metadata'])) html_error('Video Metadata Not Found');
		$json = $json['flashvars']['metadata'];

		if (empty($json['movie']['title'])) html_error('Video Title Not Found');

		$this->streams = array();
		foreach ($json['videos'] as $video) {
			if (array_key_exists($video['name'], $this->formats) && !empty($video['url'])) $this->streams[$video['name']] = $video['url'];
		}
}