<?php
include 'func.php';
$url='https://m.zingmp3.vn/bai-hat/Ve-Ben-Anh/ZW9FICD6.html';
preg_match('/data-source="(.*?)"/is',curl($url),$match);
$url='https://mp3.zing.vn/xhr'.$match[1];
$data=curl($url);
echo $data;
?>