<?php
if($link=$_POST['link']){
$ex_id=explode('.',basename($link));
$id=$ex_id[0];
$url='http://api.mp3.zing.vn/api/streaming/audio/'.$id.'/128';
$ch=curl_init();
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_USERAGENT,$ua);
curl_setopt($ch,CURLOPT_HEADER,true);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_ENCODING,'gzip');
curl_setopt($ch,CURLOPT_URL,$url);
preg_match('/^Location: (.+)$/im',curl_exec($ch),$matches);
$link128=trim($matches[1]);
if($link128){
$url='https://zingmp3.vn/embed/song/'.$id;
curl_setopt($ch,CURLOPT_URL,$url);
$html=curl_exec($ch);
preg_match('/<title>(.+?)<\/title>/is',$html,$match);
$ex=explode('|',$match[1]);
$ex=explode('-',$ex[0]);
$set[title]=trim($ex[0]);
$set[artist]=trim($ex[1]);
preg_match('/.*<meta.+?property="og:image".+?content="(.+?)".*/',$html,$arr_img);
$set[image]=trim($arr_img[1]);
$set[128]=$link128;
$json=['err'=>0,'msg'=>'success','data'=>$set];
}else{
$json=['err'=>1,'msg'=>'By Nguyenpro'];
}
curl_close($ch);
echo json_encode($json);
}
?>