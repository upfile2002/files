<?php
if($url=$_POST['link']){
$server='soundcloud.com';
if(!preg_match("/https:\/\/m.$server\/.*\/.*/is",$url)){
$ex=explode($server,$url);
$url='https://m.'.$server.$ex[1];
}
$ch=curl_init();
curl_setopt_array($ch,array(CURLOPT_USERAGENT=>'Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19',CURLOPT_RETURNTRANSFER=>1));
curl_setopt($ch,CURLOPT_URL,$url);
$html=curl_exec($ch);
if(preg_match('/<meta.+?name="twitter:audio:source".+?content="(.+?)">/is',$html,$arrurl)){
curl_setopt($ch,CURLOPT_URL,$arrurl[1]);
$data=json_decode(curl_exec($ch),true);
$data=$data[tracks][0];
$link128=$data[sources][1][url];
if(isset($link128)){
$set[title]=$data[title];
$set[image]=$data[artwork];
$set[128]=$link128;
$json=['err'=>0,'msg'=>'success','data'=>$set];
}}
if(!$json){
$json=['err'=>1,'msg'=>'By Nguyenpro'];
}
echo json_encode($json);
}
?>