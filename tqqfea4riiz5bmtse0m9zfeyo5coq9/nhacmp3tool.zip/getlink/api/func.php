<?php
function curl($url,$header=null){
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
$head[]="Connection: keep-alive";
$head[]="Keep-Alive: 300";
$head[]="Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[]="Accept-Language: en-us,en;q=0.5";
curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19');
if($header=='header'){
curl_setopt($ch,CURLOPT_HEADER,true);
curl_setopt($ch,CURLOPT_NOBODY,true);
}
curl_setopt($ch,CURLOPT_ENCODING,'');
curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
$json=curl_exec($ch);
curl_close($ch);
return $json;
}
?>