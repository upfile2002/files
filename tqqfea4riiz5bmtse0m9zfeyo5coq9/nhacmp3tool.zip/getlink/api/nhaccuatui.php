<?php
$link=$_POST['link'];
if(isset($link)){
if(preg_match('/.*nhaccuatui.com\/(.*?)\/.*\.(.+?)\.html/is',$link,$match)){
$id=$match[2];
if($match[1]=='video'){$type='videos';}else{$type='songs';}
$ex_id=explode('.',basename($link));
$id=$ex_id[1];
$data=getlink($id,$type);
}else{
$data=['err'=>1,'msg'=>'Link không hợp lệ!'];
}
echo json_encode($data);
}
function getlink($id,$type){
$url='https://graph.nhaccuatui.com/v1/'.$type.'/'.$id.'?access_token='.gettoken();
$ch=curl_init();
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19');
curl_setopt($ch,CURLOPT_ENCODING,'');
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
$json=curl_exec($ch);
curl_close($ch);
$data=json_decode($json,true);
if($data[code]=='0'){
if($type=='songs'){
foreach([128=>11,320=>12,'lossless'=>19] as $kb=>$pri){
$kbps[$kb]=$data[data][$pri];
}
$set[title]=$data[data][2];
$set[artist]=$data[data][3];
$set[image]=$data[data][8];
$set[link]=$kbps;
}else{
$arr_p=$data[data][12];
for($i=0;$i<count($arr_p);$i++){
$p=$arr_p[$i][1];
$kbps[$p]=$arr_p[$i][4];
}
$set[title]=$data[data][2];
$set[artist]=$data[data][4];
$set[image]=$data[data][3];
$set[link]=$kbps;
}
$json=['err'=>0,'msg'=>'success','data'=>$set];
}else{
$json=['err'=>2,'msg'=>'By Nguyenpro'];
}
return $json;
}
function gettoken(){
$head[]='Content-Type: application/x-www-form-urlencoded';
$head[]='Host: graph.nhaccuatui.com';
$head[]='Connection: Keep-Alive';
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,'https://graph.nhaccuatui.com/v1/commons/token');
curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19');
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
curl_setopt($ch,CURLOPT_POST,1);
curl_setopt($ch,CURLOPT_POSTFIELDS, "deviceinfo=%7B%22DeviceID%22%3A%22dd03852ada21ec149103d02f76eb0a04%22%2C%22DeviceName%22%3A%22AppTroLyBeDieu%22%2C%22OsName%22%3A%22WINDOWS%22%2C%22OsVersion%22%3A%228.0%22%2C%22AppName%22%3A%22NCTTablet%22%2C%22AppTroLyBeDieu%22%3A%221.3.0%22%2C%22UserName%22%3A%220%22%2C%22QualityPlay%22%3A%22128%22%2C%22QualityDownload%22%3A%22128%22%2C%22QualityCloud%22%3A%22128%22%2C%22Network%22%3A%22WIFI%22%2C%22Provider%22%3A%22NCTCorp%22%7D&md5=ebd547335f855f3e4f7136f92ccc6955&timestamp=1499177482892");
$json=curl_exec($ch);
$data=json_decode($json,true);
$token=$data[data][accessToken];
return $token;
}
?>