<?php
include 'func.php';
if($link=$_POST['link']){
$ex_id=explode('.',basename($link));
$id=$ex_id[0];
$url='http://api.mp3.zing.vn/api/mobile/video/getvideoinfo?requestdata={"id":"'.$id.'"}';
$data=json_decode(curl($url),true);
foreach($data[source] as $p=>$l){
if($l){
$kbps[$p]=$l;
$xuly='yes';
}}
if($xuly=='yes'){
$set[title]=$data[title];
$set[artist]=$data[artist];
$set[image]='https://zmp3-photo-fbcrawler.zadn.vn/'.$data[thumbnail];
$set[link]=$kbps;
$json=['err'=>0,'msg'=>'success','data'=>$set];
}else{
$json=['err'=>1,'msg'=>'By Nguyenpro'];
}
echo json_encode($json);
}
?>