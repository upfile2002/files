<?php
$url='https://nhac.vn/bai-hat/co-ai-du-thien-soDqA5Q';
$html=file_get_contents($url);
if(preg_match('/\'id\':([0-9]+)/',$html,$match)){
$id=$match[1];
if(preg_match("/jwplayer\('myaudio'\).setup\((.*?)\);/is",$html,$match)){
$text=$match[1];
preg_match('/.*<meta.+?property="og:image".+?content="(.+?)".*/',$html,$img);
preg_match("/description.+?'(.+?)'/is",$text,$casi);



$url='http://api.nhac.vn/client/song/listen?profile_id=7&id='.$id;
$data=json_decode(file_get_contents($url),true);
$lossless='download.php?url='.urlencode($data['data']['streaming_url']).'&filename=ok.mp3';
$kbps[lossless]=$lossless;
$set[title]='okok';
$set[artist]=$casi[1];
$set[image]='https://i1.sndcdn.com/artworks-000598846721-upzirp-t500x500.jpg';
$set[link]=$kbps;
$json=['err'=>0,'msg'=>'success','data'=>$set];
echo json_encode($json);
}}
?>