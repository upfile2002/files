<?php
include 'head.php';
echo '<div id="container"><div id="inputSection"><form method="post" onSubmit="return false;"><input type="text" name="link" id="link" placeholder="Nhập link MP3 Zing hoặc NhacCuaTui hoặc YouTube ..." value=""><input type="submit" id="submit" class="btn btn-success" value="Get Link"></form></div><script type="text/javascript" src="js/api.js"></script>';
?><div id="media">Định dạng link MP3 ZING phải ở dạng:<br><b>https://m.zingmp3.vn/bai-hat/Hong-Nhan/ZWA86FZB.html</b><br><br>Định dạng link MV Zing phải ở dạng:<br><b>https://m.zingmp3.vn/video-clip/Em-Gi-Oi-Jack-K-ICM/ZWAEFWIF.html</b><br><br>Định dạng link TV Zing phải ở dạng:<br><b>https://tv.zing.vn/video/Phuong-Tu-Hoang-Tap-1/IWZEIOOZ.html</b><br><br>Định dạng link MP3 NhacCuaTui phải ở dạng:<br><b>http://m.nhaccuatui.com/bai-hat/co-tham-khong-ve-phat-ho-ft-jokes-bii-ft-thien.mlnzEWoupew1.html</b><br><br>Định dạng link Video NhacCuaTui phải ở dạng:<br><b>http://m.nhaccuatui.com/video/hay-trao-cho-anh-son-tung-m-tp-ft-snoop-dogg-ft-madison-beer.cSyv5ozS1BPFA.html</b><br><br>Định dạng link YouTube phải ở dạng:<br><b>https://www.youtube.com/watch?v=SItFPrgEITM</b><br><br>Định dạng link SoundCloud phải ở dạng:<br><b>https://m.soundcloud.com/minh-quan-official/buoc-qua-doi-nhau-le-bao-binh</b><br><br>Định dạng link Nhac.vn phải ở dạng:<br><b>https://nhac.vn/bai-hat/co-chang-trai-viet-len-cay-phan-manh-quynh-somM3ry</b><br><br>Định dạng link Facebook Video phải ở dạng:<br><b>https://www.facebook.com/charlieputh/videos/10156089234224433/</b><br></div><div id="onlineSection" class="await ds"><div class="line dummy">Online</div></div>



<div id="fb-root"></div>
		<script>(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s); js.id = id;
		js.src = 'https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.11&appId=2001734540086293';
fjs.parentNode.insertBefore(js, fjs);
}(document,'script','facebook-jssdk'));</script><br><br><p></p><p><i>Đang fix Zing MP3. Thân !</i></p><div id="fbWrapper"><div class="fb-comments" data-href="#" data-order-by="reverse_time" data-width="100%" data-numposts="5"></div></div><h3 id="musicFixed"><a href="" target="_blank">MP3 VIDEO</a></h3><p id="copyright"><a href="https://www.facebook.com/VXNpro" target="_blank">&copy; Nguyenpro</a></p></div></body></html>