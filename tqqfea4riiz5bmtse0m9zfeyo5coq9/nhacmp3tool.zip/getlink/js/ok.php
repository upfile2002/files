<?php
$ok=strtr(file_get_contents('ahihi.js'),['n.'=>'res.']);
file_put_contents('okok.js',$ok);