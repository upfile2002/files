<?php
$url=$_GET['url'];
$filename=$_GET['filename'];
if($url&&$filename){
$size=strlen(file_get_contents($url));
if($size>0&&$url){
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment;filename='.$filename);
header('Content-Length: '.$size);
readfile($url);
exit;
}}else{

}
?>