<?php
$link=$_POST['link'];
if(isset($link)){



}else{

}
echo json_encode($json);