<!DOCTYPE html>
<html lang="vi">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>
        Em Gì Ơi - Jack, K-ICM
    </title>
    <meta name="description" content="Em Gì Ơi Jack, K-ICM Nghe download tải lời bài hát Em Gì Ơi của ca sĩ Jack, K-ICM mp3 320kbps lossless Chất lượng cao Miễn phí."/>
    <meta name="keywords" content="Em Gì Ơi, bai hat Em Gì Ơi, Em Gì Ơi Jack, K-ICM mp3, nghe bai hat Em Gì Ơi, tai bai hat Em Gì Ơi, loi bai hat Em Gì Ơi, bai hat Em Gì Ơi"/>
    <meta name="title" content="Em Gì Ơi - Jack, K-ICM | Nghe Tải Lời Bài Hát"/>
    <link rel="icon" type="image/png" href="//zingmp3.tk/static/images/icon.png"/>
    <meta property="og:title" content="Em Gì Ơi - Jack, K-ICM | Nghe Tải Lời Bài Hát"/>
    <meta property="og:description" content="Em Gì Ơi - Jack, K-ICM Nghe download tải lời bài hát Em Gì Ơi của ca sĩ Jack, K-ICM mp3 320kbps lossless Chất lượng cao Miễn phí."/>
    <meta property="og:site_name" content="TrumGet"/>
    <meta property="og:image" content="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/cover/3/5/3/f/353f305006cc99e50ef00877e4135d0e.jpg"/>
    <meta property="og:type" content="music.song"/>
    <link rel="image_src" href="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/cover/3/5/3/f/353f305006cc99e50ef00877e4135d0e.jpg"/>
    <meta http-equiv="refresh" content="300"/>
    <meta name="referrer" content="never"/>
    <link rel="stylesheet" href="//zingmp3.tk/static/css/index.css" type="text/css">
    <style type="text/css">
    a {
        text-decoration: none !important;
    }

    .downbtn {
        padding: 2px !important;
        font-weight: 200 !important;
        font-size: 12px !important;
    }

    .image_avatar {
        animation: app-logo-spin infinite 5s linear;
        width: 100px;
        height: 100px;
        border-radius: 50%;
    }

    p {
        margin-bottom: 5px !important;
    }

    @keyframes app-logo-spin {
        from {
            transform: rotate(0deg)
        }

        to {
            transform: rotate(360deg)
        }
    }
    </style>
    <link rel="stylesheet" href="//zingmp3.tk/static/css/bootstrap.min.css">
    <script type="text/javascript" src="//zingmp3.tk/static/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" charset="utf-8" async="" src="//zingmp3.tk/static/js/head.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        if ($(document).width() < 650) {
            $("#progress").attr('style', 'right: 160px;');
            $("#play_time").attr('style', 'right: 80px;');
            $("#speaker").attr('style', 'display: none;');
            $(".volume").attr('style', 'display: none;');
        }
    });
    let downloadlink = {"128":"//mp3-s1-zmp3.zadn.vn/82e92cd20995e0cbb984/7970188110350163799?authen=exp=1571356675~acl=/82e92cd20995e0cbb984/*~hmac=124d2611975ea072e7527f7f692d4760&filename=Em-Gi-Oi-Jack-K-ICM.mp3","320":"//mp3-320s1-zmp3.zadn.vn/22a98b92aed5478b1ec4/4747968672200872159?authen=exp=1571356675~acl=/22a98b92aed5478b1ec4/*~hmac=3ff9f40bdf01c93882d5a530aed7c683&filename=Em-Gi-Oi-Jack-K-ICM.mp3","lossless":"//mp3-lossless-zmp3.zadn.vn/f5045a3f7f789626cf69/4208172806183216821?authen=exp=1571356675~acl=/f5045a3f7f789626cf69/*~hmac=12cfaf8ab786ffab0125803e7cc45719&filename=Em-Gi-Oi-Jack-K-ICM.flac"}

    function chatluong(chatluong) {
        $("#audio").html(`<source src="http:${downloadlink[chatluong]}" type="audio/mpeg">`)
        $("#squality").hide();
        if (chatluong == 'lossless') {
            $(".squality").html('Lossless▼')
        } else {
            $(".squality").html(chatluong + 'kbps▼')
        }
        audio.load();
        playAudio();
    }

    function taive(chatluong) {
        window.open(`http:${downloadlink[chatluong]}`)
    }
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-123668334-5"></script>
    <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-123668334-5');</script>

</head>

<body>
    <div class="container" style="margin-top: 10px">
        <div class="row" style="padding: 0px;">
            <div class="col-sm-8" style="padding: 0px">
                <div id="content">
                    <div class="box-shadow">
                        <div class="info">
                            <div class="avatar"><script data-pagespeed-no-defer>//<![CDATA[
(function(){for(var g="function"==typeof Object.defineProperties?Object.defineProperty:function(b,c,a){if(a.get||a.set)throw new TypeError("ES3 does not support getters and setters.");b!=Array.prototype&&b!=Object.prototype&&(b[c]=a.value)},h="undefined"!=typeof window&&window===this?this:"undefined"!=typeof global&&null!=global?global:this,k=["String","prototype","repeat"],l=0;l<k.length-1;l++){var m=k[l];m in h||(h[m]={});h=h[m]}var n=k[k.length-1],p=h[n],q=p?p:function(b){var c;if(null==this)throw new TypeError("The 'this' value for String.prototype.repeat must not be null or undefined");c=this+"";if(0>b||1342177279<b)throw new RangeError("Invalid count value");b|=0;for(var a="";b;)if(b&1&&(a+=c),b>>>=1)c+=c;return a};q!=p&&null!=q&&g(h,n,{configurable:!0,writable:!0,value:q});var t=this;function u(b,c){var a=b.split("."),d=t;a[0]in d||!d.execScript||d.execScript("var "+a[0]);for(var e;a.length&&(e=a.shift());)a.length||void 0===c?d[e]?d=d[e]:d=d[e]={}:d[e]=c};function v(b){var c=b.length;if(0<c){for(var a=Array(c),d=0;d<c;d++)a[d]=b[d];return a}return[]};function w(b){var c=window;if(c.addEventListener)c.addEventListener("load",b,!1);else if(c.attachEvent)c.attachEvent("onload",b);else{var a=c.onload;c.onload=function(){b.call(this);a&&a.call(this)}}};var x;function y(b,c,a,d,e){this.h=b;this.j=c;this.l=a;this.f=e;this.g={height:window.innerHeight||document.documentElement.clientHeight||document.body.clientHeight,width:window.innerWidth||document.documentElement.clientWidth||document.body.clientWidth};this.i=d;this.b={};this.a=[];this.c={}}function z(b,c){var a,d,e=c.getAttribute("data-pagespeed-url-hash");if(a=e&&!(e in b.c))if(0>=c.offsetWidth&&0>=c.offsetHeight)a=!1;else{d=c.getBoundingClientRect();var f=document.body;a=d.top+("pageYOffset"in window?window.pageYOffset:(document.documentElement||f.parentNode||f).scrollTop);d=d.left+("pageXOffset"in window?window.pageXOffset:(document.documentElement||f.parentNode||f).scrollLeft);f=a.toString()+","+d;b.b.hasOwnProperty(f)?a=!1:(b.b[f]=!0,a=a<=b.g.height&&d<=b.g.width)}a&&(b.a.push(e),b.c[e]=!0)}y.prototype.checkImageForCriticality=function(b){b.getBoundingClientRect&&z(this,b)};u("pagespeed.CriticalImages.checkImageForCriticality",function(b){x.checkImageForCriticality(b)});u("pagespeed.CriticalImages.checkCriticalImages",function(){A(x)});function A(b){b.b={};for(var c=["IMG","INPUT"],a=[],d=0;d<c.length;++d)a=a.concat(v(document.getElementsByTagName(c[d])));if(a.length&&a[0].getBoundingClientRect){for(d=0;c=a[d];++d)z(b,c);a="oh="+b.l;b.f&&(a+="&n="+b.f);if(c=!!b.a.length)for(a+="&ci="+encodeURIComponent(b.a[0]),d=1;d<b.a.length;++d){var e=","+encodeURIComponent(b.a[d]);131072>=a.length+e.length&&(a+=e)}b.i&&(e="&rd="+encodeURIComponent(JSON.stringify(B())),131072>=a.length+e.length&&(a+=e),c=!0);C=a;if(c){d=b.h;b=b.j;var f;if(window.XMLHttpRequest)f=new XMLHttpRequest;else if(window.ActiveXObject)try{f=new ActiveXObject("Msxml2.XMLHTTP")}catch(r){try{f=new ActiveXObject("Microsoft.XMLHTTP")}catch(D){}}f&&(f.open("POST",d+(-1==d.indexOf("?")?"?":"&")+"url="+encodeURIComponent(b)),f.setRequestHeader("Content-Type","application/x-www-form-urlencoded"),f.send(a))}}}function B(){var b={},c;c=document.getElementsByTagName("IMG");if(!c.length)return{};var a=c[0];if(!("naturalWidth"in a&&"naturalHeight"in a))return{};for(var d=0;a=c[d];++d){var e=a.getAttribute("data-pagespeed-url-hash");e&&(!(e in b)&&0<a.width&&0<a.height&&0<a.naturalWidth&&0<a.naturalHeight||e in b&&a.width>=b[e].o&&a.height>=b[e].m)&&(b[e]={rw:a.width,rh:a.height,ow:a.naturalWidth,oh:a.naturalHeight})}return b}var C="";u("pagespeed.CriticalImages.getBeaconData",function(){return C});u("pagespeed.CriticalImages.Run",function(b,c,a,d,e,f){var r=new y(b,c,a,e,f);x=r;d&&w(function(){window.setTimeout(function(){A(r)},0)})});})();pagespeed.CriticalImages.Run('/mod_pagespeed_beacon','https://zingmp3.tk/bai-hat/Em-Gi-Oi-Jack-K-ICM/ZWAEFWIF.html','2L-ZMDIrHf',true,false,'xZxreReRWdg');
//]]></script><img class="image_avatar" src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/cover/3/5/3/f/353f305006cc99e50ef00877e4135d0e.jpg" alt="Jack, K-ICM" data-pagespeed-url-hash="212235130" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></div>
                            <div>
                                <h1 id="title" class="inline">
                                    Em Gì Ơi
                                </h1>
                                <h2 id="title" class="inline fwn">
                                    Jack, K-ICM
                                </h2>
                            </div>
                            <div class="left-info">
                                <p><b>Sáng tác:</b>
                                    Jack
                                </p>
                                <p><b>Thể loại:</b>
                                    Việt Nam, Nhạc Trẻ, V-Pop, 
                                </p>
                                <div class="clear" style="margin-top: 3px;"></div>
                                <button type="button" class="btn btn-success downbtn" onclick="taive('128')">128kbps</button>
                                <button type="button" class="btn btn-info downbtn" onclick="taive('320')">320kbps</button>
                                
                                <button type="button" class="btn btn-danger downbtn" onclick="taive('lossless')">Lossless</button>
                                
                            </div>
                            <div class="clear"></div>
                        </div>
                        <script type="text/javascript" src="//zingmp3.tk/static/js/html5.js"></script>
                        <div class="player">
                            <div class="background"></div>
                            <div class="cut-blur">
                                <div class="cover" style="background-image: url('https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/cover/3/5/3/f/353f305006cc99e50ef00877e4135d0e.jpg');"></div>
                            </div>
                            <div class="hide-html5">
                                <audio id="audio" controls="" autoplay="" preload="auto">
                                    <source src="//mp3-320s1-zmp3.zadn.vn/22a98b92aed5478b1ec4/4747968672200872159?authen=exp=1571356675~acl=/22a98b92aed5478b1ec4/*~hmac=3ff9f40bdf01c93882d5a530aed7c683&filename=Em-Gi-Oi-Jack-K-ICM.mp3" type="audio/mpeg">
                                    <div class="menu">Trình duyệt của bạn không hỗ trợ HTML5</div>
                                </audio>
                            </div>
                            <div id="play" class="pause control"></div>
                            <div id="progress">
                                <div id="progress_box">
                                    <div id="load_progress" style="width: 100%;">
                                        <div class="hand-control" id="hand_progress" style="left: 182.199px;"></div>
                                        <div id="play_progress" style="width: 189.199px;"></div>
                                    </div>
                                </div>
                            </div>
                            <div id="play_time">
                                <span id="current_time_display">00:00 / 00:00</span>
                            </div>
                            <div id="speaker"></div>
                            <div class="volume">
                                <span class="volumebar">
                                    <div class="volumehandle"></div>
                                </span>
                            </div>
                            <div class="quality" data-id="wbux">
                                <div class="squality" onclick="show('squality');">320kbps▼</div>
                                <div id="squality" style="display: none;">
                                    <div class="qmenu"><a href="javascript:;" onclick="chatluong('128')">128kbps</a></div>
                                    <div class="qmenu"><a href="javascript:;" onclick="chatluong('320')">320kbps</a></div>
                                    
                                    <div class="qmenu"><a href="javascript:;" onclick="chatluong('lossless')">Lossless</a></div>
                                    
                                </div>
                            </div>
                        </div>
                        <h2 id="lyric">Lời bài hát
                            Em Gì Ơi
                        </h2>
                        <p id="full-lyric" class="line-lyric">
                            Đừng khóc như thế
<br>Xin đừng khóc như thế
<br>Bao nhiêu niềm đau chôn dấu
<br>Mong ngày sẽ trôi mau
<br>Đời phong ba, độc thân bước chân Sơn Hà
<br>
<br>Buổi sáng hôm ấy
<br>Khi còn trắng sương bay
<br>Ta như là gió phiêu lãng
<br>Mang hành lý thương nhớ
<br>Chẳng sao đâu, sầu bi có khi còn lâu
<br>Lạc mình trong cánh buồm phiêu du
<br>Chiếc thuyền đong đưa
<br>Những ngày xa xưa
<br>Bé nhỏ hay thưa Mẹ thưa Cha
<br>Rằng con đi học mới về
<br>Giờ tung bay, khúc nhạc mê say
<br>Nỗi lòng tha hương, vướng đường tương lai
<br>Ước rằng ngày mai nắng lên
<br>Ngày mai nắng lên ta sẽ quên
<br>Này này này là em gì ơi
<br>Em gì ơi, em gì ơi!
<br>Ở lại và yêu được không 
<br>Yêu được không, yêu được không
<br>Thật lòng này ta chỉ mong ta chỉ mong 
<br>Bên dòng sông, người có nhớ có trông ai...
<br>Việc gì phải ôm buồn đau 
<br>Riêng mình ta riêng mình ta
<br>Nụ cười nở muôn ngàn hoa 
<br>Muôn ngàn hoa, muôn ngàn hoa
<br>Cuộc đời này thật là vui biết bao
<br>Trời cao núi xanh mây ngàn sao
<br>Khi bánh xe còn lăn bánh
<br>Khi bánh xe còn lăn bánh
<br>Ta xoay vòng với cuộc sống hối hả 
<br>Quên đi mộng ước thanh xuân đã trôi qua
<br>Ta ngại va chạm khi nhiều lần dối trá
<br>Những lần áp lực bởi công việc muốn đi xa
<br>Vứt hết một lần trước khi nhìn đời thoái hóa 
<br>Tự do tự tại như chim trời và thi ca
<br>Bước qua nà
<br>Đời nhiều lúc cảm thấy rất nhiều trò
<br>Thôi ta giang tay ôm lấy cả bầu trời!
<br>Hỡi bạn thân ơi! Lá mù u rơi
<br>Khát vọng ra khơi, chúng mình đi chơi
<br>Bước thật hiên ngang, lối về thênh thang
<br>Chẳng cần cao sang, nỗi lòng sang trang và từ nay
<br>Lạc mình trong cánh buồm phiêu du
<br>Chiếc thuyền đong đưa
<br>Những ngày xa xưa
<br>Bé nhỏ hay thưa Mẹ thưa Cha
<br>Rằng con đi học mới về
<br>Giờ tung bay, khúc nhạc mê say
<br>Nỗi lòng tha hương, vướng đường tương lai
<br>Ước rằng ngày mai nắng lên
<br>Ngày mai nắng lên ta sẽ quên
<br>Này này này là em gì ơi
<br>Em gì ơi, em gì ơi!
<br>Ở lại và yêu được không 
<br>Yêu được không, yêu được không
<br>Thật lòng này ta chỉ mong ta chỉ mong 
<br>Bên dòng sông, người có nhớ có trông ai...
<br>Việc gì phải ôm buồn đau 
<br>Riêng mình ta riêng mình ta
<br>Nụ cười nở muôn ngàn hoa 
<br>Muôn ngàn hoa, muôn ngàn hoa
<br>Cuộc đời này thật là vui biết bao
<br>Trời cao núi xanh mây ngàn sao
<br>Này này này là em gì ơi
<br>Em gì ơi, em gì ơi!
<br>Ở lại và yêu được không 
<br>Yêu được không, yêu được không
<br>Thật lòng này ta chỉ mong ta chỉ mong 
<br>Bên dòng sông, người có nhớ có trông ai...
<br>Việc gì phải ôm buồn đau 
<br>Riêng mình ta riêng mình ta
<br>Nụ cười nở muôn ngàn hoa 
<br>Muôn ngàn hoa, muôn ngàn hoa
<br>Cuộc đời này thật là vui biết bao
<br>Trời cao núi xanh mây ngàn sao
                        </p>
                        <div class="clear"></div>
                        <div class="tool-content">
                            <div class="more-lyric" onclick="showcontent('lyric');">Xem toàn bộ ▼</div>
                            <div class="cut-lyric" onclick="cutcontent('lyric');" style="display: none;">Thu gọn ▲</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4" style="padding: 0px">
                <div class="box-shadow">
                    <h3 class="title">VỪA NGHE XONG</h3>
                    <div class="menu">
                        <div class="s-avatar">
                            <div class="arank1">1</div><a href="/bai-hat/Em-Gi-Oi-Jack-K-ICM/ZWAEFWIF.html" title="Em Gì Ơi - Jack, K-ICM"><img src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/cover/3/5/3/f/353f305006cc99e50ef00877e4135d0e.jpg" alt="Jack, K-ICM" data-pagespeed-url-hash="212235130" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/Em-Gi-Oi-Jack-K-ICM/ZWAEFWIF.html" title="Em Gì Ơi - Jack, K-ICM"><b class="text">Em Gì Ơi</b></a></p>
                        <div id="singer">
                            <p class="inline">Jack, K-ICM</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank2">2</div><a href="/bai-hat/Em-Gi-Oi-Jack-K-ICM/ZWAEFWIF.html" title="Em Gì Ơi - Jack, K-ICM"><img src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/cover/3/5/3/f/353f305006cc99e50ef00877e4135d0e.jpg" alt="Jack, K-ICM" data-pagespeed-url-hash="212235130" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/Em-Gi-Oi-Jack-K-ICM/ZWAEFWIF.html" title="Em Gì Ơi - Jack, K-ICM"><b class="text">Em Gì Ơi</b></a></p>
                        <div id="singer">
                            <p class="inline">Jack, K-ICM</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank3">3</div><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><img src="https://photo-zmp3.zadn.vn/audio_default.png" alt="Song Lục" data-pagespeed-url-hash="3742898687" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><b class="text">123 em yêu anh- Song Lục.mp3</b></a></p>
                        <div id="singer">
                            <p class="inline">Song Lục</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank4">4</div><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><img src="https://photo-zmp3.zadn.vn/audio_default.png" alt="Song Lục" data-pagespeed-url-hash="3742898687" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><b class="text">123 em yêu anh- Song Lục.mp3</b></a></p>
                        <div id="singer">
                            <p class="inline">Song Lục</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank5">5</div><a href="/bai-hat/Nguoi-Con-Trai-Ay-Nguyen-Dinh-Vu/ZW9BZBDZ.html" title="Người Con Trai Ấy - Nguyễn Đình Vũ"><img src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/avatars/7/f/7f9a94cfc18c6ec42392c94f051f3fd6_1487383519.jpg" alt="Nguyễn Đình Vũ" data-pagespeed-url-hash="2389604089" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/Nguoi-Con-Trai-Ay-Nguyen-Dinh-Vu/ZW9BZBDZ.html" title="Người Con Trai Ấy - Nguyễn Đình Vũ"><b class="text">Người Con Trai Ấy</b></a></p>
                        <div id="singer">
                            <p class="inline">Nguyễn Đình Vũ</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank6">6</div><a href="/bai-hat/Nguoi-Con-Trai-Ay-Nguyen-Dinh-Vu/ZW9BZBDZ.html" title="Người Con Trai Ấy - Nguyễn Đình Vũ"><img src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/avatars/7/f/7f9a94cfc18c6ec42392c94f051f3fd6_1487383519.jpg" alt="Nguyễn Đình Vũ" data-pagespeed-url-hash="2389604089" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/Nguoi-Con-Trai-Ay-Nguyen-Dinh-Vu/ZW9BZBDZ.html" title="Người Con Trai Ấy - Nguyễn Đình Vũ"><b class="text">Người Con Trai Ấy</b></a></p>
                        <div id="singer">
                            <p class="inline">Nguyễn Đình Vũ</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank7">7</div><a href="/bai-hat/Nguoi-Con-Trai-Ay-Nguyen-Dinh-Vu/ZW9BZBDZ.html" title="Người Con Trai Ấy - Nguyễn Đình Vũ"><img src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/avatars/7/f/7f9a94cfc18c6ec42392c94f051f3fd6_1487383519.jpg" alt="Nguyễn Đình Vũ" data-pagespeed-url-hash="2389604089" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/Nguoi-Con-Trai-Ay-Nguyen-Dinh-Vu/ZW9BZBDZ.html" title="Người Con Trai Ấy - Nguyễn Đình Vũ"><b class="text">Người Con Trai Ấy</b></a></p>
                        <div id="singer">
                            <p class="inline">Nguyễn Đình Vũ</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank8">8</div><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><img src="https://photo-zmp3.zadn.vn/audio_default.png" alt="Song Lục" data-pagespeed-url-hash="3742898687" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><b class="text">123 em yêu anh- Song Lục.mp3</b></a></p>
                        <div id="singer">
                            <p class="inline">Song Lục</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank9">9</div><a href="/bai-hat/Nhung-Giac-Mo-Dai-My-Linh/ZWZCWII6.html" title="Những Giấc Mơ Dài - Mỹ Linh"><img src="https://photo-resize-zmp3.zadn.vn/w240_r1x1_jpeg/covers/2/7/2760735506a5bc187a35f6c829fae70d_1306293291.jpg" alt="Mỹ Linh" data-pagespeed-url-hash="574016159" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/Nhung-Giac-Mo-Dai-My-Linh/ZWZCWII6.html" title="Những Giấc Mơ Dài - Mỹ Linh"><b class="text">Những Giấc Mơ Dài</b></a></p>
                        <div id="singer">
                            <p class="inline">Mỹ Linh</p>
                        </div>
                        <div class="clear"></div>
                    </div><div class="menu">
                        <div class="s-avatar">
                            <div class="arank10">10</div><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><img src="https://photo-zmp3.zadn.vn/audio_default.png" alt="Song Lục" data-pagespeed-url-hash="3742898687" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p><a href="/bai-hat/123-em-yeu-anh-Song-Luc-mp3-Song-Luc/ZW9BFEEI.html" title="123 em yêu anh- Song Lục.mp3 - Song Lục"><b class="text">123 em yêu anh- Song Lục.mp3</b></a></p>
                        <div id="singer">
                            <p class="inline">Song Lục</p>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">bodyLoaded();audio.load();playAudio();</script>
</body>

</html>