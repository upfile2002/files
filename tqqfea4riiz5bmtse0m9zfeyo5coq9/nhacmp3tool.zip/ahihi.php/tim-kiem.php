<?php
$q=str_ireplace('-', ' ', $_GET['q']);
if(empty($q)){
header("location:/");
exit;
}
include 'set.php';
include 'func.php';
$title='Tìm Kiếm: '.$q;
include 'head.php';
$html=curl('http://m.nhaccuatui.com/tim-kiem/bai-hat?q='.urlencode($q).'&b=title&sort=0');
$v=explode('<div class="item_thumb">',$html);
$max=(count($v)-1);
echo '<div class="top-menu">';
if($max>1){
echo '<div class="top-menu-item-first"><h1>Kết quả cho từ khóa: '.$q.'</h1> </div>';
for($i=1;$i<$max;$i++){
preg_match('#bai-hat/(.*?)"#',$v[$i],$l);
preg_match('#title="(.*?)">#',$v[$i],$title);
$name=explode(' - ',$title[1]);
echo '<div class="list"><p><b><a href="/bai-hat/'.$l[1].'" title="Tải Bài Hát '.$title[1].'">'.$name[0].'</a></b></p><i style="font-size: 15px">'.$name[1].'</i></div>';
}}else{
echo '<div class="top-menu-item-first"><h2>Không có kết quả nào phù hợp với từ khóa bạn tìm. Vui lòng thử lại bằng từ khóa khác!</h2></div>';
}
echo '</div>';
include 'end.php';
?>