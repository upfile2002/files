<?php
include 'set.php';
include 'func.php';
if(isset($_GET['name'])){
$name=$_GET['name'];
$temp=explode(".",$name);
$id=trim($temp[1]);
$token=gettoken();
$data=getlink($id,$token);
$url=$data->data->{6};
$name=explode('/',$url);
$url='http://m.nhaccuatui.com/bai-hat/'.$name[4];
$linkplay=$data->data->{7};
$link['320']=$data->data->{12};
$link['128']=$data->data->{11};
$thumbnail=$data->data->{8};
$name=$data->data->{2};
$casi=$data->data->{3};
if(empty($name)){
header("location: /");
exit;
}
$title='Tải Bài Hát '.$name;
include 'head.php';
echo '<style> .download { font-weight: bold; color: #fff; background: #d9534f; padding: 5px 10px; font-size: 15px !important; width: 200px; text-align: center; border-radius: 5px; /* border: 1px solid #fff; */ display: block; margin: 10px auto; } .download { background: #f3420ded; } </style> <div class="detail"> <ul class="more"> <li><h1>Tải Bài Hát '.$name.'</h1></li> <li style="font-style: italic; font-size: 12px;">Ca sĩ: '.$casi.'</li> </ul> </div> <audio controls loop preload="none"> <source src="'.$linkplay.'" type="audio/mpeg" /> Trình duyệt của bạn không hỗ trợ HTML5 Audio </audio><p>';
foreach([320,128] as $kbps){
echo '<a href="'.$link[$kbps].'" class="download" title="Tải bài hát '.$name.' - '.$casi.'">Tải về chất lượng '.$kbps.'kbps</a>';
}
$html=curl($url);
$l=explode('<p class="lyric">',$html);
$lyric=explode('</p>',$l[1]);
$lyric=$lyric[0];
if($lyric){
$hlyric='<div class="top-menu-item-first"><h2>Lời Bài Bát</h2></div> <div class="top-menu-item"><span class="read-more-content"><div class="bh-lyric" id="bh-lyric">'.$lyric.'</div><div class="more"><button><a class="lr" onclick="return false;" href="#">Xem đầy đủ</a></button></div></span></div>';
}
echo '</p><div class="top-menu">'.$hlyric.'<div class="top-menu-item-first"><h2>Tải bài hát tương tự</h2></div>';
$v=explode('<div class="item_thumb">',$html);
for($i=1;$i<=5;$i++){
preg_match('#bai-hat/(.*?)"#',$v[$i],$l);
preg_match('#title="(.*?)">#',$v[$i],$title);
$name=explode(' - ',$title[1]);
echo '<div class="list"><p><b><a href="/bai-hat/'.$l[1].'" title="Tải Bài Hát '.$title[1].'">'.$name[0].'</a></b></p> <i style="font-size: 15px">'.$name[1].'</i></div>';
}
echo '</div>';
include 'end.php';
}else{
header("location: /");
}
?>