<?php
function page($sotrang,$page,$url = '') {
if ($sotrang > 1){
echo '<div class="paging">';
if ($page > 1){
echo '<a href="?p='.($page-1).'">&laquo;</a>';
}
if ($page > 1){
echo '<a href="?p=1">1</a>';
}
if ($page > 4){
echo '<span>..</span>';
}
if ($page > 3){
echo '<a href="?p='.($page-2).'">'.($page-2).'</a>';
}
if ($page > 2){
echo '<a class="pagenav" href="?p='.($page-1).'">'.($page-1).'</a>';
}
if ($sotrang > 1){
echo '<span><b>'.$page.'</b></span>';
}
if ($page < ($sotrang-1)){
echo '<a href="?p='.($page+1).'">'.($page+1).'</a>';
}
if ($page < ($sotrang-2)){
echo '<a href="?p='.($page+2).'">'.($page+2).'</a>';
}
if ($page < ($sotrang-3)){
echo '<span>..</span>';
}
if ($page < $sotrang){
echo '<a href="?p='.$sotrang.'">'.$sotrang.'</a>';
}
if ($page < $sotrang){
echo '<a href="?p='.($page+1).'">&raquo;</a>';
}
echo '</div>';
}
}
function ago($time_ago) {
$timeht = time();
$times = $time_ago;
$time_giay = $timeht - $times;
 $time_phut = floor($time_giay / 60);
$time_day = date('z',$timeht)-date('z',$times);
$fulltime = date('d.m.Y / H:i',$time_ago);
$minitime = date('H:i',$time_ago);
if ($time_day == 0) {
if ($time_giay <= 60) {
$sw = $time_giay.' giây trước';
} elseif ($time_phut <= 60) {
$sw = $time_phut.' phút trước';
} else {
$sw = 'Hôm nay, '.$minitime;
} 
} elseif ($time_day == 1) {
$sw = 'Hôm qua, '.$minitime;
} else {
$sw =$fulltime;
}
return $sw;
}
?>