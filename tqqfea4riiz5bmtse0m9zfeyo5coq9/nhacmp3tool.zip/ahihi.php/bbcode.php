<?php
function ndurl($matches){
$ret = '';
$url = $matches['2'];
if (empty($url))
return $matches['0'];
if (in_array(substr($url, -1),array('.',',',';',':')) === true){
$ret = substr($url, -1);
$url = substr($url, 0,strlen($url)-1);
}
return $matches['1'].' <a href="'.$url.'" target="_blank">'.$url.'</a>'.$ret;
}
function ndlink($ret){
$ret = ' '.$ret;
$ret = preg_replace_callback('#([\s>])([\w]+?://[\w\\x80-\\xff\#$%&~/.\-;:=,?@\[\]+]*)#is','ndurl',$ret);
$ret = preg_replace('#(<a( [^>]+?>|>))<a [^>]+?>([^>]+?)</a></a>#i','$1$3</a>',$ret);
$ret = trim($ret);
return $ret;
}
function smile($sml){
$tet = ':D :)) :) :3 :vx: :vl: :vote: :v :(( :( =)) :good: :hack: :rip: :wow: :yeah: :ym: :yaoming: :what: :troll: :troi: :1lol: :2lol: :amen: :ban: :bom: :brick: :buoi: :buon: :buonngu: :chan: :chao: :chay: :chay2: :choang: :choang2: :clgt: :dau: :dc: :decu: :den: :die: :dien: :dkm: :fa: :fu: :gach: :ge: :ha: :haha: :haiz: :hehe: :help: :her: :hi: :hihi: :hix: :hixhix: :hoho: :hohuha: :hu: :iurui: :kaka: :keke: :khong: :leuleu: :loa: :lol: :love: :met: :nan: :ngap: :ngau: :ngau2: :ngo: :ngon: :no: :nono: :o: :oa: :oaoa: :oe: :oeoe: :oil: :oil2: :oil3: :pun: :suyt: :them: :tien: :tuc: :x: :xi: :xoaybong: :xoaybong2: :xoaybong3: :sad: :sogood: :sosad:';
$nam = explode(' ',$tet);
foreach($nam as $key => $value){
$img = str_replace(':','',$value);
$resml = array(
')' => '1',
'))' => '2',
'(' => '6',
'((' => '4',
'=))' => '5'
);
$img = '<img src="http://senko.sextgem.com/smile/'.strtr($img,$resml).'.gif">';
$sml = str_replace($value, $img, $sml);
}
return $sml;
}
function bb($ndp){
$ndp = preg_replace('#\[audio\](.*?)\[/audio\]#is', '<center><audio controls> <source src="$1" type="audio/mpeg"> <embed height="80" width="320" autostart="0" src="$1"> <noembed> 000</noembed></audio></center>', $ndp);
$ndp = preg_replace('#\[img\](.*?)\[/img\]#is', '<center><img src="$1" alt="[IMG]" style="max-width: 98%;" class="image" /></center>', $ndp);
$ndp = preg_replace('#\[color=(.*?)](.*?)\[/color\]#is', '<font color="$1">$2</font>', $ndp);
$ndp = preg_replace('#\[url=(.*?)](.*?)\[/url\]#is', '<a href="$1" target="_blank" class="noload">$2</a>', $ndp);
$ndp = preg_replace('#\[url\](.*?)\[/url\]#is', '<a href="$1" target="_blank" class="noload">$1</a>', $ndp);
$ndp = preg_replace('#\[b\](.*?)\[/b\]#is', '<b>$1</b>', $ndp);
$ndp = preg_replace('#\[i\](.*?)\[/i\]#is', '<i>$1</i>', $ndp);
$ndp = preg_replace('#\[u\](.*?)\[/u\]#is', '<u>$1</u>', $ndp);
$ndp = preg_replace('#\[youtube\](.*?)\[/youtube\]#is', '<iframe preload="auto" src="https://www.youtube.com/embed/$1?autoplay=0" frameborder="0" allowfullscreen></iframe>', $ndp);
$ndp = preg_replace('#\[video\](.*?)\[/video\]#is', '<video width="auto" controls><source src="$1" type="video/mp4">
</video>', $ndp);
$ndp = smile($ndp);
return $ndp;
}
function bbcode($py) {
$rep = array(
':' => '<:>',
'=' => '<=>',
'[' => '<[>',
']' => '<]>'
);
preg_match_all('#\[code](.+?)\[\/code]#is',$py,$pupy);
$tong = count($pupy[0])-1;
for($i=0;$i<=$tong;$i++){
$pp = $pupy[0][$i];
$sc= strpos($pp,'[code]');
$ec= strpos($pp,'[/code]');
$code = substr($pp,($sc+6),($ec-$sc-6));
$copy = strtr($code,$rep);
$py = str_replace('[code]'.$code.'[/code]','<div class="phdr">Copy Code</span></div><div class="list1">'.$copy.'</div>',$py);
}
$black = array(
'<:>' => ':',
'<=>' => '=',
'<[>' => '[',
'<]>' => ']',
);
$py = bb($py);
$py = strtr($py,$black);
return ndlink(nl2br($py));
}
?>