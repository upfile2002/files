$(document).ready(function() {
  $('.bh-lyric').css('max-height','135px');
  ($('.more').html() == '' && $('.bh-lyric').css('height') == '135px') ? $('.more').html('<a class="lr" onclick="return false;" href="#">Xem đầy đủ</a>') : '';

    $(".lr").click(function() {
      if($('.bh-lyric').css('max-height')=='100%')
      {
        $('.bh-lyric').css('max-height','135px');
        $('.lr').html('Xem đầy đủ');
        $('html, body').animate({
        scrollTop: $("#bh-lyric").offset().top
        }, 0);
      } else {
        $('.bh-lyric').css('max-height','100%');

        $('.lr').html('Thu Gọn');
      }
    });
});

$("#qr").submit(function(e){
  if ($('#q').val().length == 0 || $.trim($('#q').val()) == '') {
        return false;
  }
});

const text = document.querySelector('.text');
const button = document.querySelector('.button');
const message = document.querySelector('.message');

button.onclick = function () {
  // Select the text
  text.select();
  
  // Copy it
  document.execCommand('copy');
  
  // Remove focus from the input
  text.blur();
  
  // Show message
  message.classList.add('active');
  
  // Hide message after 2 seconds
  setTimeout(function () {
    message.classList.remove('active');
  }, 2000);
};