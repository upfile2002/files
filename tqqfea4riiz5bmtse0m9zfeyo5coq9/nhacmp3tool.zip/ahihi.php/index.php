<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
include 'head.php';
include 'func.php';
include 'bbcode.php';
$nd = $conn->real_escape_string(htmlspecialchars($_POST['nd']));
$ten = $conn->real_escape_string(htmlspecialchars($_POST['ten']));
if ($ten == '#xoa 119' || $nd == '#xoa 119') {
$conn->query('TRUNCATE TABLE chat');
} elseif (trim($ten) != '' && trim($nd) != '') {
if (!$conn->query("SELECT * FROM chat")) {
$sql = "CREATE TABLE chat (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
ten VARCHAR(50) NOT NULL,
nd TEXT,
time int
)";
$conn->query($sql);
}
$sql = "INSERT INTO chat (ten, nd, time) VALUES ('{$ten}', '{$nd}',".time().")";
$conn->query($sql);
}
$u = $conn->query("SELECT COUNT(id) as ui FROM chat");
$u = $u->num_rows > 0 ? $u->fetch_assoc()['ui'] : 0;
echo '<div class="phdr">Phòng Chat ('.$u.')</div>
<div class="list1">
<form method="post">
Tên:
<br />
<input type="text" name="ten">
Nội dung:
<br />
<textarea name="nd"></textarea>
<br />
<input type="submit" value="Chat">
</form></div>';
$p = isset($_GET['p']) ? $_GET['p'] : 1;
$per = 10;
$page_max = ceil($u / $per);
if ($p > $page_max){
$p = $page_max;
} else if ($p < 1){
$p = 1;
}
$start = ($p - 1) * $per;
$sql = "SELECT * FROM chat ORDER BY id DESC LIMIT $start,$per";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
while($row = $result->fetch_assoc()) {
echo '<div class="list1"><b>'.$row["ten"].'</b>: '.bbcode($row["nd"]).' <span style="color: #999">'.ago($row["time"]).'</span></div>';
}
} else {
echo '<div class="list1">Phòng chat trống</div>';
}
$conn->close();
page($page_max,$p);
include 'end.php';
?>