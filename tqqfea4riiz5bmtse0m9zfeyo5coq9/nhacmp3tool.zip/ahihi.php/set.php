<?php
//By Nguyenpro
$domain='Nhac.Xp3.Biz';
?>