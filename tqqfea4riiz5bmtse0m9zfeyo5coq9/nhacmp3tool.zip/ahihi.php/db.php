<?php
$conn = new mysqli('localhost', 'userData', 'pass', 'database');
if ($conn->connect_error) {
die("Kết nối thất bại: " . $conn->connect_error);
}
?>