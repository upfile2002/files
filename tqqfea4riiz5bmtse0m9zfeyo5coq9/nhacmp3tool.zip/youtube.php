<?php
$itag=['5'=>['FLV','240p'],'6'=>['FLV','270p'],'13'=>['3GP','mobile'],'17'=>['3GP','144p'],'18'=>['MP4','360p'],'22'=>['MP4','720p'],'34'=>['FLV','360p','0'],'35'=>['FLV','480p'],'36'=>['3GP','240p'],'37'=>['MP4','1080p'],'38'=>['MP4','3072p'],'43'=>['WEBM','360p'],'44'=>['WEBM','480p'],'45'=>['WEBM','720p'],'46'=>['WEBM','1080p'],'82'=>['MP4','3D 360p'],'83'=>['MP4','3D 480p'],'84'=>['MP4','3D 720p'],'85'=>['MP4','3D 1080p'],'100'=>['WEBM','3D 360p'],'101'=>['WEBM','3D 480p'],'102'=>['WEBM','3D 720p']];
$id='WX7dUj14Z00';
$data=getlink($id);
if($data){
foreach ($data as $i=>$link){
echo '<div class="list1"><a href="'.$link.'&title=[WapDinhBay.Wap.Sh]-'.$title.'" title="'.$title.'">Tải Xuống định dạng '.$itag[$i][0].' ('.$itag[$i][1].')</a></div>';
}}else{
echo '[er]error[/er]';
}
function curl($url){
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
$head[]="Connection: keep-alive";
$head[]="Keep-Alive: 300";
$head[]="Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[]="Accept-Language: en-us,en;q=0.5";
curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
curl_setopt($ch,CURLOPT_TIMEOUT,60);
curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,60);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));
$page=curl_exec($ch);
curl_close($ch);
return $page;
}
function getlink($id){
$getlink="https://www.youtube.com/watch?v=".$id;
if($html=curl($getlink)){
$return=array();
if(preg_match('/;ytplayer\.config\s*=\s*({.*?});/',$html,$data)){
$jsonData=json_decode($data[1],true);
$json=$jsonData['args']['url_encoded_fmt_stream_map'];
if($json){
foreach(explode(',',$json) as $url){
$url=str_replace('\u0026','&',$url);
$url=urldecode(urldecode($url));
parse_str($url,$data);
$dataURL=$data['url'];
unset($data['url']);
$return[$data['itag']]=$dataURL.'&'.http_build_query($data);
}}
return $return;
}else{
return 0;
}}else{
return 0;
}}
?>