<?php
function zingmp3getinfo($id){
$url="https://m.zingmp3.vn/bai-hat/By-Nguyenpro/$id.html";
preg_match('/data-source="(.*?)"/is',curl($url),$match);
$url='https://mp3.zing.vn/xhr'.$match[1];
$data=json_decode(curl($url),true);
$json[name]=$data[data][name];
$json[casi]=$data[data][performer];
$img=str_replace('w94_r1x1_jpeg','w340_r1x1_jpeg',$data[data][thumbnail]);
$json[img]=$img;
$kbps=$data[data][source];
$kbps[32]='';
$filename=rwurl($json[name].'-'.strtr($json[casi],[','=>'']).'.mp3');
if($kbps[128]){
$linkplay=$kbps[128];
}else{
$linkplay=$kbps[320];
}
$json[linkplay]='http:'.$linkplay;

print_r($kbps);
foreach($kbps as $kb=>$link){
if($link){
$kblink[$kb]=$link;
}else{
$kblink[$kb]='/mp3convert.php?url='.urlencode($json[linkplay]).'&kbps='.$kb.'&filename='.$filename;
}}
$json[link]=$kblink;
$lyric=curl($data[data][lyric]);
$lyric=preg_replace('#\[(.*?)\]#is','',$lyric);
$lyric=str_replace(["\n","\r\n"],'<br/>',$lyric);
$json[lyric]=$lyric;

$url='https://mp3.zing.vn/xhr/recommend?type=audio&id='.$id;
$res=json_decode(curl($url),true);
$res=$res[data][items];
for($i=0;$i<count($res);$i++){
$data=$res[$i];
$id=$data[id];
$set[name]=$data[name];
$set[casi]=$data[artists_names];
$ex=explode('/',$data[link]);
$set[path]=titurl($ex[2]).".zingmp3.$id.html";
$recommend[]=$set;
$json[recommend]=$recommend;
unset($set);
}
return json_encode($json);
}

function nctgetinfo($id){
$link='https://graph.nhaccuatui.com/v1/songs/'.$id.'?access_token='.nctgettoken();
$data=json_decode(curl($link),true);
$url=$data[data][6];
$url=strtr($url,['www'=>'m','s:'=>':']);
$thumbnail=$data[data][8];
$json[name]=$data[data][2];
$json[casi]=$data[data][3];
$filename=rwurl($json[name].'-'.strtr($json[casi],[','=>'']).'.mp3');
$json[linkplay]=$data[data][7];
$kbps['320']=$data[data][12];
$kbps['128']=$data[data][11];
$kbps['32']='/mp3convert.php?url='.urlencode($kbps['128']).'&kbps=32&filename='.$filename;
$html=curl($url);
$ex=explode('<div class="cover">',$html);
$ex=explode('</div>',$ex[1]);
preg_match('#<img.+?src="(.+?)".+?title=".+?">#',$ex[0],$img);
$json[img]=$img[1];
$json[link]=$kbps;
$ex=explode('<p class="lyric">',$html);
$lyric=explode('</p>',$ex[1]);
$json[lyric]=$lyric[0];
$ex=explode('<div class="item_thumb">',$html);
for($i=1;$i<=10;$i++){
preg_match('#<a.+?type="nowplaying-song".+?href="(.+?)".+?title="(.+?)">#',$ex[$i],$match);
$url=$match[1];
$title=$match[2];
$ex_name=explode('.',basename($url));
$ex_title=explode(' - ',$title);
$set[path]="/bai-hat/$ex_name[0].nhaccuatui.$ex_name[1].html";
$set[name]=trim($ex_title[0]);
$set[casi]=trim($ex_title[1]);
$recommend[]=$set;
$json[recommend]=$recommend;
unset($set);
}
return json_encode($json);
}






function bxhnct(){
$exp=explode('<div class="box_info">',curl('http://m.nhaccuatui.com/bai-hat/top-20.nhac-viet.html'));
for($i=1;$i<(count($exp)-1);$i++){
$ex=$exp[$i];
preg_match('#<a.+?href="(.+?)">(.+?)</a>#',$ex,$arr);
$arrex=explode('class="singer_song">',$ex);
$arrex=explode('</h4>',$arrex[1]);
$extit=explode('/',$arr[1]);
$extit=explode('.',$extit[4]);
$set[name]=$arr[2];
$set[casi]=$arrex[0];
$set[titurl]="$extit[0].nhaccuatui.$extit[1].html";
$return[]=$set;
unset($set);
}
return json_encode($return);
}

function bxhzingmp3(){
$json=curl('https://mp3.zing.vn/xhr/chart-realtime');
$data=json_decode($json,true);
$json=$data[data][song];
for($i=0;$i<count($json);$i++){
$data=$json[$i];
$id=$data[id];
$set[name]=$data[title];
$set[casi]=$data[performer];
$ex=explode('/',$data[link]);
$set[titurl]=titurl($ex[2]).".zingmp3.$id.html";
$return[]=$set;
unset($set);
}
return json_encode($return);
}

function curl($url){
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
$head[]="Connection: keep-alive";
$head[]="Keep-Alive: 300";
$head[]="Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[]="Accept-Language: en-us,en;q=0.5";
curl_setopt($ch,CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19');
curl_setopt($ch,CURLOPT_ENCODING, '');
curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch,CURLOPT_TIMEOUT,60);
curl_setopt($ch,CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
curl_setopt($ch,CURLOPT_HTTPHEADER, array('Expect:'));
$page=curl_exec($ch);
curl_close($ch);
return $page;
}
function rwurl($title){
$replacement='-';
$map=array();
$quotedReplacement=preg_quote($replacement,'/');
$default = array(
'/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ|å/' => 'a',
'/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/' => 'A',
'/e|è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ|ë/' => 'e',
'/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/' => 'e',
'/ì|í|ị|ỉ|ĩ|î/' => 'i',
'/Ì|Í|Ị|Ỉ|Ĩ/' => 'I',
'/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ|ø/' => 'o',
'/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/' => 'O',
'/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ|ů|û/' => 'u',
'/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/' => 'U',
'/ỳ|ý|ỵ|ỷ|ỹ/' => 'y',
'/Ỳ|Ý|Ỵ|Ỷ|Ỹ/' => 'Y',
'/đ/' => 'd',
'/Đ/' => 'D',
'/ç/' => 'c',
'/ñ/' => 'n',
'/æ/' => 'ae',
'/ä/' => 'a',
'/ö/' => 'o',
'/ü/' => 'u',
'/Ä/' => 'A',
'/Ü/' => 'U',
'/Ö/' => 'O',
'/ß/' => 'b',
'/̃|̉|̣|̀|́/' => '',
'/ /'=>$replacement,
sprintf('/^[%s]+|[%s]+$/',$quotedReplacement,$quotedReplacement)=>'',
);
$title=urldecode($title);
mb_internal_encoding('UTF-8');
$map = array_merge($map, $default);
return preg_replace(array_keys($map), array_values($map), $title) ;
}
function titurl($title){
$replacement = '-';
$map = array();
$quotedReplacement = preg_quote($replacement, '/');
$default = array(
'/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ|À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ|å/' => 'a',
'/e|è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ|È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ|ë/' => 'e',
'/ì|í|ị|ỉ|ĩ|Ì|Í|Ị|Ỉ|Ĩ|î/' => 'i',
'/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ|Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ|ø/' => 'o',
'/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ|Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ|ů|û/' => 'u',
'/ỳ|ý|ỵ|ỷ|ỹ|Ỳ|Ý|Ỵ|Ỷ|Ỹ/'=> 'y',
'/đ|Đ/' => 'd',
'/ç/' => 'c',
'/ñ/' => 'n',
'/ä|æ/' => 'ae',
'/ö/' => 'o',
'/ü/' => 'u',
'/Ä/' => 'A',
'/Ü/' => 'U',
'/Ö/' => 'O',
'/ß/' => 'b',
'/̃|̉|̣|̀|́/' => '',
'/[^\s\p{Ll}\p{Lm}\p{Lo}\p{Lt}\p{Lu}\p{Nd}]/mu' => ' ', '/\\s+/' => $replacement,
sprintf('/^[%s]+|[%s]+$/', $quotedReplacement, $quotedReplacement) => '',
);
$title = urldecode($title);
mb_internal_encoding('UTF-8');
$map = array_merge($map, $default);
return strtolower( preg_replace(array_keys($map), array_values($map), $title) );
}

function nctgettoken(){
$headers[]='Content-Type: application/x-www-form-urlencoded';
$headers[]='Host: graph.nhaccuatui.com';
$headers[]='Connection: Keep-Alive';
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,"https://graph.nhaccuatui.com/v1/commons/token");
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch,CURLOPT_POST,1);
curl_setopt($ch,CURLOPT_POSTFIELDS, "deviceinfo=%7B%22DeviceID%22%3A%22dd03852ada21ec149103d02f76eb0a04%22%2C%22DeviceName%22%3A%22AppTroLyBeDieu%22%2C%22OsName%22%3A%22WINDOWS%22%2C%22OsVersion%22%3A%228.0%22%2C%22AppName%22%3A%22NCTTablet%22%2C%22AppTroLyBeDieu%22%3A%221.3.0%22%2C%22UserName%22%3A%220%22%2C%22QualityPlay%22%3A%22128%22%2C%22QualityDownload%22%3A%22128%22%2C%22QualityCloud%22%3A%22128%22%2C%22Network%22%3A%22WIFI%22%2C%22Provider%22%3A%22NCTCorp%22%7D&md5=ebd547335f855f3e4f7136f92ccc6955&timestamp=1499177482892");
$page=curl_exec($ch);
curl_close($ch);
$infotoken=json_decode($page);
$token=$infotoken->data->accessToken;
return $token;
}
function mp3convert($url,$kbps,$khz){
$server='https://www.online-convert.com';
$ch=curl_init();
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
curl_setopt($ch,CURLOPT_HEADER,true);
curl_setopt($ch,CURLOPT_URL,$server.'/fileupload');
$nguyenpro=['target'=>'mp3','category'=>'audio','external_url'=>$url,'audio_bitrate'=>$kbps,'frequency'=>$khz,'string_method'=>'convert-to-mp3'];
curl_setopt($ch,CURLOPT_POST,count($nguyenpro));
curl_setopt($ch,CURLOPT_POSTFIELDS,$nguyenpro);
$head_html=curl_exec($ch);
preg_match('/^Location: (.+)$/im',$head_html,$match);
$url=trim($match[1]);
if(preg_match('#result#is',$url)){
curl_setopt($ch,CURLOPT_URL,$url);
$html=curl_exec($ch);
preg_match('/<iframe.+?id="download_try".+?src="(.+?)".+?<\/iframe>/is',$html,$arr_preg);
$url=$arr_preg[1];
for($i=0;$i<100;$i++){
curl_setopt($ch,CURLOPT_URL,$url);
$html=curl_exec($ch);
if(preg_match('/<div.+?class="no-js-download-link">.+?<a href="(.+?)">/is',$html,$arr_link)){
return $arr_link[1];
exit;
}}}}
?>