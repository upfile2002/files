<?php
echo '<div class="footer"><p>Hệ thống <b><a style="color:#f00" href="/" title="tai nhac mp3 mien phi">Tải nhạc miễn phí</a></b> cho điện thoại, nhạc mp3 chất lượng cao. Tải video clip nhạc, album nhạc hót.
Nhạc trên website MP3ZING.INFO lấy từ hệ thống mp3.zing.vn và nhaccuatui.com - website nghe nhạc số 1 VN. Cập nhật đầy đủ bảng xếp hạng bài hát, video, album, full lời bài hát.<br/><i>Wap tai nhac hay, download nhac mp3</i></p>'.$domain.' © 2019</div>';
?>