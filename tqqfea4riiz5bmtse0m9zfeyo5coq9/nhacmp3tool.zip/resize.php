<?php
list($url,$w,$h)=([$_GET['url'],$_GET['w'],$_GET['h']]);
if($url&&$w&&$h){
$size=strlen(file_get_contents($url));
if($size<1){
}elseif(!is_numeric($w)||!is_numeric($h)||$w==0||$h==0){
}else{
header('Content-Type: image/jpg');
resize($url,$w,$h);
}}
function resize($img,$width,$height){
$info=getimagesize($img);
switch($info['mime']){
case 'image/png':
$image_create="imagecreatefrompng";
$image="imagepng";
break;
case 'image/jpeg':
$image_create="imagecreatefromjpeg";
$image="imagejpeg";
break;
case 'image/gif':
$image_create="imagecreatefromgif";
$image="imagegif";
break;
default:
return false;
break;
}
$from=$image_create($img);
$src=imagecreatetruecolor($width,$height);
imagecopyresampled($src,$from,0,0,0,0,$width,$height,imagesx($from),imagesy($from));
$color='#000000';
$redback=hexdec(substr($color,1,2));
$greenback=hexdec(substr($color,3,2));
$blueback=hexdec(substr($color,5,2));
$blue=imagecolorallocate($src,$redback,$greenback,$blueback);
imagecolortransparent($src,$blue);
$image($src);
}
?>