<?php
$q=str_ireplace('-', ' ', $_GET['q']);
if(empty($q)){
header("location:/");
exit;
}
include 'set.php';
include 'func.php';
$title='Tìm Kiếm: '.$q;
include 'head.php';
$json=json_decode(search($q),true);$max=count($json);
echo '<div class="top-menu">';
if($max>1){
echo '<div class="top-menu-item-first"><h1>Kết quả cho từ khóa: '.$q.'</h1> </div>';
for($i=0;$i<$max;$i++){
$data=$json[$i];
$path=$data[path];
$name=$data[name];
$casi=$data[artist];
echo '<div class="list"><p><b><a href="'.$path.'" title="Tải Bài Hát '.$title.'">'.$name.'</a></b></p><i style="font-size: 15px">'.$casi.'</i></div>';
}}else{
echo '<div class="top-menu-item-first"><h2>Không có kết quả nào phù hợp với từ khóa bạn tìm. Vui lòng thử lại bằng từ khóa khác!</h2></div>';
}
echo '</div>';
include 'end.php';
function search($q){
$url='http://ac.mp3.zing.vn/complete?type=artist,song,key,code&num=500&query='.urlencode($q);
$json=json_decode(curl($url),true);
$json=$json[data][0][song];
$maxz=count($json);
$html=curl('http://m.nhaccuatui.com/tim-kiem/bai-hat?q='.urlencode($q).'&b=title&sort=0');
$ex=explode('<div class="item_thumb">',$html);
$maxk=(count($ex)-3);
$count=($maxz+$maxk-1);
list($y,$k)=[0,1];
for($i=0;$i<$count;$i++){
if(($i%2)==0&&$y<$maxz||$k>=$maxk){
$data=$json[$y];
$set[path]="/bai-hat/ok.zingmp3.$data[id].html";
$set[name]=$data[name];
$set[artist]=$data[artist];
$return[]=$set;
unset($set);
$y++;
}else{
preg_match('#<a.+?type="nowplaying-song".+?href="(.+?)".+?title="(.+?)">#',$ex[$k],$match);
$url=$match[1];
$title=$match[2];
$ex_name=explode('.',basename($url));
$ex_title=explode(' - ',$title);
$set[path]="/bai-hat/$ex_name[0].nhaccuatui.$ex_name[1].html";
$set[name]=trim($ex_title[0]);
$set[artist]=trim($ex_title[1]);
$return[]=$set;
unset($set);
$k++;
}}
return json_encode($return,true);
}
?>